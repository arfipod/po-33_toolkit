PO-33 K.O! – Game Boy / Chiptune Pack

Original synthetic samples inspired by classic handheld chiptune sound design.

FORMAT
- WAV mono
- 44.1 kHz
- 16-bit PCM
- Names 01..16 compatible with the previous HTML sample-board app.

MAP
01 Pulse Lead C5
02 Square Lead C5
03 Arp Pluck C5
04 Wave Bass C2
05 C major chord
06 A minor chord
07 F major chord
08 G major chord
09 Coin / blip FX
10 Chip kick
11 Chip snare
12 Chip clap
13 Closed noise hat
14 Open noise hat
15 Laser FX
16 Noise explosion

EXTRAS
- PO33_transfer_01_to_16.wav
- DEMO_150BPM_2bars.wav

SOUND DESIGN
- pulse/square waves with classic duty-cycle variations
- coarse 4-bit-style wave bass
- pseudo-LFSR noise for percussion and FX
- pitch sweeps and short amplitude envelopes

SUGGESTED PO-33 USE
- 01–04: melodic slots; repitch for melodies/basslines
- 05–08: chord stabs
- 09, 15, 16: game-like FX
- 10–14: drum kit

All sounds are original and generated from scratch.
